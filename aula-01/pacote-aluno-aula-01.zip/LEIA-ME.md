# Aula 01 - Pacote do Aluno

**Conectar GHL com Claude - 12.05.2026 - Triadeflow**

---

## Conteudo

```
pacote-aluno/
  LEIA-ME.md                            <- voce esta aqui
  INSTALAR-STACK-GHL.md                 <- auto-instalador (recomendado)
  00-material-agentes-ghl.html          <- apresentacao visual
  01-skill-triade-ghl-mastery.pdf       <- PDF explicando a skill
  agents/
    high-ghl.md                         <- @high - GHL Specialist
    rev-revops.md                       <- @revops - Head RevOps
    convo-conversation-ai.md            <- @convo - Conversation AI Architect
  skills/triade-ghl-mastery/
    SKILL.md                            <- skill GHL Triadeflow
  secrets/
    ghl-clients.example.json            <- modelo do arquivo de credenciais
```

---

## Caminho 1 - Instalacao automatica (recomendado)

Voce poe o Claude Code pra instalar tudo pra voce. 1 unico comando.

### 1. Instale o Claude Code

```bash
# Mac / Linux / WSL
curl -fsSL https://claude.ai/install.sh | bash

# Windows (PowerShell)
irm https://claude.ai/install.ps1 | iex
```

Depois `claude login` pra autenticar.

### 2. Abra o Claude Code dentro desta pasta

```bash
cd pacote-aluno
claude
```

### 3. Cole esse pedido

```
leia INSTALAR-STACK-GHL.md e execute a instalacao exatamente como descrito
```

O Claude vai:
- Detectar seu sistema (Mac / Linux / Windows)
- Criar as pastas em `~/.claude/`
- Copiar os 3 agentes
- Copiar a skill
- Criar o template de credenciais
- Pedir pra voce preencher o token PIT do GHL

Pronto. Em 2 minutos voce esta com o stack instalado.

---

## Caminho 2 - Instalacao manual (so se quiser entender o que esta acontecendo)

### 1. Instale o Claude Code

Mesmo passo do caminho 1.

### 2. Crie as pastas

```bash
# Mac / Linux
mkdir -p ~/.claude/agents ~/.claude/skills ~/.claude/secrets

# Windows (PowerShell)
$base = "$env:USERPROFILE\.claude"
New-Item -ItemType Directory -Force -Path "$base\agents", "$base\skills", "$base\secrets"
```

### 3. Copie os arquivos

- 3 agentes da pasta `agents/` para `~/.claude/agents/`
- Pasta `skills/triade-ghl-mastery/` inteira para `~/.claude/skills/`
- Arquivo `secrets/ghl-clients.example.json` para `~/.claude/secrets/`

### 4. Configure suas credenciais GHL

4.1 - GHL > Settings > Private Integrations > Create New Integration
- Marque escopos: Contacts, Opportunities, Workflows, Custom Fields, Conversations
- Copie o token (aparece **uma unica vez**)

4.2 - GHL > Settings > Business Info > Location ID (copie)

4.3 - Renomeie `ghl-clients.example.json` para `ghl-clients.json` (tira o `.example`) e preencha.

---

## Como saber se deu certo

Abra o Claude Code numa pasta qualquer e pergunte:

```
liste os agentes disponiveis e as skills com "ghl" no nome
```

Tem que aparecer:
- Agentes: `@high`, `@revops`, `@convo`
- Skill: `triade-ghl-mastery`

Se aparecer, esta tudo no ar.

---

## Primeiro pedido

```
@high leia ~/.claude/secrets/ghl-clients.json e use
location_id e pit_token de "default" pra listar todos
os pipelines da minha conta GHL. mostra nome, id e
quantos stages cada um tem.
```

Se voltar a lista dos seus pipelines, voce conectou GHL ao Claude.

---

## Regras importantes

- **NUNCA** suba `ghl-clients.json` pra GitHub publico, Drive aberto ou chat
- **NUNCA** rode primeiro teste em subconta de cliente real - use subconta de teste
- **SEMPRE** peca pro Claude listar antes de apagar em massa
- **SEMPRE** chame `@revops` antes de pipeline novo (Rev desenha, High implementa)

---

## Ordem de uso dos agentes na pratica

```
@revops (Rev)  ->  desenha o processo comercial
   |
   v
@high (High)   ->  implementa no GHL (pipelines, fields, workflows)
   |
   v
@convo (Convo) ->  cria bots e Voice AI quando o processo pede
```

A skill `triade-ghl-mastery` roda silenciosa por baixo dos tres, dando contexto tatico sempre que o assunto for GHL.

---

## Suporte

- WhatsApp Alex Campos: **+55 19 98380-5908**
- Email: **contato@triadeflow.com.br**

Sem vergonha de perguntar.

---

*Triadeflow / Aulas Terca 19h / Aula 01 - 12.05.2026*
