---
name: triade-ghl-mastery
description: GoHighLevel CRM mastery - pipelines, workflows, custom fields, Conversation AI bots, webhooks, and RevOps automation. Carregue automaticamente quando o contexto envolver operacao no GoHighLevel (criacao de pipelines, configuracao de workflows, gerenciamento de custom fields, integracao de Conversation AI bots, webhooks, RevOps automation, audit de subcontas, troubleshooting de API GHL).
---

# triade-ghl-mastery

Skill operacional do Claude pra trabalhar em GoHighLevel com fluencia de operador Triadeflow.

## Quando ativar

Esta skill carrega automaticamente quando a conversa toca em GoHighLevel, GHL, HUB (apelido interno Triadeflow) ou qualquer assunto que envolva:

- Pipelines e stages
- Workflows e automacoes
- Custom fields em Contact ou Opportunity
- Conversation AI bots
- Voice AI
- Webhooks (entrada e saida)
- API GHL (PIT tokens, OAuth, endpoints v2)
- Tags e segmentacao
- Migracao de dados pra GHL (Kommo, ActiveCampaign, etc)
- Integracoes externas com o GHL (ERP, Asana, Notion, Postgres, Langfuse)

## Gotchas embutidos

### API typos que sao reais
- Campo `MONETORY` (sem H) - GHL escreve assim, nao corrija
- `appoinmentPerSlot` (sem T) no setup de calendario - typo permanece na API
- Errar isso quebra request silenciosamente

### Cloudflare bloqueia Python-urllib default
- Scripts Python que batem em `services.leadconnectorhq.com` precisam User-Agent de browser
- Sem User-Agent customizado, GHL retorna erro 1010 do Cloudflare
- Solucao: setar header `User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36`

### PIT tokens expiram
- Personal Integration Tokens nao tem TTL fixo, mas podem ser revogados sem aviso
- Monitorar: se uma chamada que sempre funcionou comeca a 401, o token foi revogado
- Solucao: gerar novo em Settings > Private Integrations

### Template WhatsApp da Meta tem rate limit
- 1 edit por template HSM a cada 24h
- HUB UI volta pra lista de templates mesmo em fail 422 (subcode 2388124)
- Hookar XHR e verificar status 200 antes de marcar workflow como completed

### Nome de atendente em template
- SEMPRE usar `{{user.first_name}}` pra puxar primeiro nome
- NUNCA usar `{{user.email_signature}}` (eh a assinatura completa, nao o nome)
- Garantir "Assign Contact to User" antes de Send Template no workflow

### Canal SMS vs WhatsApp via Stevo
- Stevo (provider nao oficial WhatsApp) intercepta acao Send SMS no workflow
- Send WhatsApp nativo so funciona com Twilio ou Meta pago
- Vale pra Whapi, Z-API e Evolution tambem

## Convencoes Triadeflow

### Discovery antes de criar
- Sempre GET nos existentes antes de POST novo
- Evita duplicatas de campo, tag, pipeline
- Regra para toda integracao

### Credenciais nunca em doc compartilhada
- PIT, IDs, location_id, quotas ficam em arquivos locais
- Nunca commitar em repo publico
- Nunca colar em Notion/KB de cliente
- Referenciar por env var ou arquivo local fora do projeto

### Nomenclatura
- "GHL" e usado em codigo, configs, logs
- "HUB" e o apelido usado pra cliente (nunca dizer "GHL" pra cliente final)
- Em material publico de aula/curso, usar "GHL" eh OK porque o aluno conhece o produto

### Server-side scheduling
- Workflows agendados sempre em servidor, NUNCA no PC local
- Cron jobs em Hetzner/Railway/Coolify
- PC local nao garante uptime

## Padroes de prompt

### Criar pipeline novo
```
@high cria pipeline {nome} com {N} stages: {lista de stages}
no GHL location {id ou referencia}. owner default {pessoa}.
documenta IDs em arquivo {nome-cliente}-implementacao.md.
```

### Importar contatos via API
```
@high importa {N} contatos do arquivo {path}. usa upsert pelo
telefone como chave. marca tag {tag} em todos. ignora os que
ja existem se {condicao}.
```

### Audit de subconta
```
@high lista todos os custom fields de Contact e Opportunity
da subconta {id}. agrupa por uso (quais workflows usam cada).
flag os que nao tem uso ativo nos ultimos 60 dias.
```

### Conexao com bot Conversation AI
```
@convo cria bot {nome} pra canal {WhatsApp/IG/SMS}. objetivo
{qualificar/agendar/responder Q&A}. fluxo: {steps}. se {condicao},
move contato pra stage {stage} do pipeline {pipeline}.
```

## API GHL v2 (referencias rapidas)

| Endpoint | Metodo | Uso |
|----------|--------|-----|
| `/contacts/` | POST | criar contato (com upsert via params) |
| `/contacts/{id}` | PUT | atualizar contato |
| `/contacts/search` | POST | buscar com filtros |
| `/opportunities/` | POST | criar opportunity |
| `/pipelines/` | GET | listar pipelines |
| `/workflows/` | GET | listar workflows |
| `/custom-fields/` | GET/POST | gerenciar custom fields |
| `/tags/` | GET | listar tags da location |

Headers obrigatorios:
```
Authorization: Bearer {pit_token}
Version: 2021-07-28
Accept: application/json
```

## Dupla com agentes

Esta skill carrega CONTEXTO. Quem executa sao os agentes:

- **@revops** desenha processo comercial antes
- **@high** implementa configs no GHL (pipelines, fields, workflows, tags)
- **@convo** cria bots e Voice AI no Conversation AI
- **@link** integracoes externas (webhooks pra fora)

A skill garante que esses agentes nao errem typo de API, nao esquecam gotcha de canal, nao ignorem convencao Triadeflow.

## Referencias

- Catalogo Pulso da IA: https://pulsodaia.com.br/skills/triade-ghl-mastery/
- GHL API Docs: https://highlevel.stoplight.io/docs/integrations/
- GHL Help Center: https://help.gohighlevel.com/

---

**Versao:** 2026-05-12 (Aula 01)
**Autor:** Alex Campos / Triadeflow
**Status:** entregavel pedagogico
